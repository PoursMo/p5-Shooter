class Bullet {
  constructor(position, direction, type, speed = 1, size = 5) {
    this.pos = position;
    this.vel = direction;
    this.size = size;
    this.type = type;
    this.speed = speed;
    if (this.type === "player") {
      playerBullets.push(this);
    } else if (this.type === "enemy") {
      enemyBullets.push(this);
    }
  }

  update() {
    this.vel.normalize();
    this.vel.mult(this.speed);
    this.pos.add(this.vel);
    if (this.pos.y < 0) {
      this.destroy();
    }
    this.show();
  }

  show() {
    push();
    if (this.type === "player") {
      fill(255, 255, 0);
      stroke(255);
    } else if (this.type === "enemy") {
      fill(255, 0, 0);
      stroke(255, 0, 0);
    }
    circle(this.pos.x, this.pos.y, this.size);
    pop();
  }

  destroy() {
    if (this.type === "player") {
      playerBullets.splice(
        playerBullets.findIndex((x) => x === this),
        1
      );
    } else if (this.type === "enemy") {
      enemyBullets.splice(
        enemyBullets.findIndex((x) => x === this),
        1
      );
    }
  }
}
